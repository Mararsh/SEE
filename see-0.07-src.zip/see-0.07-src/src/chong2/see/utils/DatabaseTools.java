package chong2.see.utils;

import chong2.see.data.base.Constants;
import chong2.see.data.base.Language;
import chong2.see.data.DataReader;
import chong2.see.data.*;
import chong2.see.xml.DataXmlWriter;

import java.util.ArrayList;
import java.util.Hashtable;
import java.sql.*;
import java.io.*;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>Title: �������̹�������</p>
 * <p>Description: Ϊ�����з��ṩ�������ݺ������ƽ̨</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ���</p>
 *
 * �����ݿ⴦����صľ�̬������
 * ��һ��δʵ��
 *
 * @author ����
 * @version 0.07
 */

final public class DatabaseTools {

/*  ===================== database methods ==================== */
//  public static DBHandler connectDB(HttpServletRequest myRequest) {
//    return connectDB(getContext(myRequest));
//  }
//
//  public static DBHandler connectDB(ServletContext myContext) {
//
//    String DBDriver = getInitConfig(myContext,"DBDriver");
//    String DBTarget = getInitConfig(myContext,"DBTarget");
//    String DBUser = getInitConfig(myContext,"DBUser");
//    String DBPassword = getInitConfig(myContext,"DBPassword");
//
//    DBHandler mydb =  new DBHandler();
//    mydb.openConnection(DBDriver,DBTarget,DBUser,DBPassword);
//
//    return mydb;
//  }

}